/** 
 * This class is created to return the JSON response as 
 *     {
 *			"status": "Success"
 *	   }
 */

package com.usageAggregator;

public class Output {

	public String status = null;
	public Output(){}
	public Output(String response)
	{
		status= response;
	}
}
