/**
 * This class is created to make the make connection with MySql DB, initializing the session factory
 *  and performing insert and fetch operation in UsageAggregator database containing table usagedata.
 */

package com.usageAggregator;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;


public class AggregatorService {

	private static SessionFactory factory = null;;

	public AggregatorService() {
	}

	/**
	 * Initialize session factory using hibernate.cfg.xml containing MySQL DB 
	 * connection parameters, and using Entity class UsageData.
	 */
	private void intializeFactory()
	{
		try
		{
			Configuration configObj = new Configuration();
			configObj.configure("hibernate.cfg.xml");
			configObj.addAnnotatedClass(UsageData.class);
			
			ServiceRegistry serviceRegistryObj = 
					new StandardServiceRegistryBuilder().applySettings(
        				configObj.getProperties()).build(); 
			
			factory = configObj.buildSessionFactory(serviceRegistryObj);
			
		} 
		catch (Throwable ex) 
		{ 
			System.out.println("Failed to create sessionFactory object." + ex);
			throw new ExceptionInInitializerError(ex); 
		}
	}
	
	/**
	 * TO insert data in usagedata table, how bytes were used by a 
	 * given subscriber at an specific timestamp.
	 * 
	 * @param usageData containing subscriberId, usage, timestamp.
	 * @return success/not success
	 */
	public Response reportUsage(UsageData usageData)
	{
		// Initialize session factory is not already done.
		if (factory == null)
		{
			System.out.println("Initialize session factory");
			intializeFactory();
		}
		Session session = factory.openSession();
	    Transaction tx = null;
	    try 
	    {
	         tx = session.beginTransaction();
	         session.save(usageData); 
	         tx.commit();
	    } 
	    catch (HibernateException e) 
	    {
	    	if (tx!=null)
	    	{
	    		tx.rollback();
	    	}
	        e.printStackTrace(); 
	        return Response.status(Status.EXPECTATION_FAILED).build();
	    } 
	    finally 
	    {
	    	session.close(); 
	    }
	    
	    // Return success if all goes well.
	    return Response.ok(new Output("Success")).build();
	}
	
	/**
	 * To retrieve data from usagedata table to calculate what was the 
	 * total usage consumed by a given subscriber per day.
	 * 
	 * @param usageData containing subscriberId
	 * @return List of aggregatedUsages of given subscriber per day.
	 */
	public List<AggregatedUsage> getAggregatedUsage(UsageData usageData)
	{	
		// Initialize session factory is not already done.
		if (factory == null)
		{
			System.out.println("Initialize session factory");
			intializeFactory();
		}
		Session session = factory.openSession();
	    Transaction tx = null;
	    
	    // Contains totalUsage per day.
	    Hashtable<String, Integer> aggregatedUsages = new Hashtable<>();
		
		//Date formatter to format the timestamp into yyyy-MM-dd to get totalUsage per day.
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		
		try 
		{
			tx = session.beginTransaction();
			String query = "FROM UsageData ud WHERE ud.subscriberId="
					+ usageData.getSubscriberId();
			System.out.println("DB query: " + query);
			List<UsageData> usages = session.createQuery(query).list();

			for (Iterator<UsageData> iterator = usages.iterator(); iterator.hasNext();) 
			{
				UsageData usage = (UsageData) iterator.next();
				
				if (usage.getTimestamp()!= null)
				{
					Date date1 = formatter.parse(usage.getTimestamp());

					// Get date in yyyy-MM-dd format
					String date2 = formatter.format(date1);

					// Add date (yyyy-MM-dd) and amount in a hashtable
					if (aggregatedUsages.containsKey(date2)) 
					{
						// In case of multiple usage records with same day but
						// different time, add the amount to previous amount with same day.
						int amount = aggregatedUsages.get(date2);
						aggregatedUsages.remove(date2);
						aggregatedUsages.put(date2, amount + usage.getAmount());
					} 
					else 
					{
						// Make a new entry in hashtable.
						aggregatedUsages.put(date2, usage.getAmount());
					}
				}
				else 
				{
					System.out.println("Timestamp is null");
				}
				
			}

			tx.commit();
		} 
		catch (HibernateException | ParseException e)
		{
			if (tx != null)
			{
				tx.rollback();
			}
			e.printStackTrace();
		} 
		finally 
		{
			session.close();
		}
		
		// Make a list of AggregatedUsage containing totalUsage and day and return the list.
		List<AggregatedUsage> usages = new ArrayList<>();
		for (String key : aggregatedUsages.keySet()) 
		{
			usages.add(new AggregatedUsage(aggregatedUsages.get(key), key));
		}
		return usages;
	}
}
