package com.usageAggregator;


/** This class is created to return the response of getAggregatedUsage API.
 * 
 * getAggregatedUsage API takes subsciberId as input and return the totalUsages for all the days.
 * 
 * e.g. Response should look like as below JSON format.
 * 
 *      {
 * 			"totalUsage": 2000000,
 *			"day": "2018-06-04"
 *		},
 *		{
 *			"totalUsage": 1000000,
 *		    "day": "2018-06-05"
 *		}
 *
 */
public class AggregatedUsage 
{
	public int totalUsage;
	public String day;
	
	public AggregatedUsage(){}
	public AggregatedUsage(int totalUsage, String day)
	{
		this.totalUsage = totalUsage;
		this.day = day;
	}
	
}
