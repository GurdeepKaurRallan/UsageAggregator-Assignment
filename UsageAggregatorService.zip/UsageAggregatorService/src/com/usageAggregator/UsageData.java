/**
 * This class is created for UsageData like subsciberId, usage and timeStamp.
 */

package com.usageAggregator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@XmlRootElement
@Table(name = "usagedata")
public class UsageData 
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column (name = "id")
	private int Id;
	
	@Column(name = "subscriberId")
	private int subscriberId;
	
	@Column(name = "amount")
	private int amount;
	
	@Column(name = "timestamp", nullable=false)
	private String timestamp;
	
	public int getId() 
	{
		return Id;
	}

	public void setId(int id) 
	{
		Id = id;
	}
	
	public int getSubscriberId() 
	{
		return subscriberId;
	}

	public void setSubscriberId(int subscriberId)
	{
		this.subscriberId = subscriberId;
	}

	public int getAmount() 
	{
		return amount;
	}

	public void setAmount(int amount) 
	{
		this.amount = amount;
	}
	
	public String getTimestamp() 
	{
		return timestamp;
	}

	public void setTimestamp(String timestamp) 
	{
		this.timestamp = timestamp;
	}

	public UsageData(int subscriberId, int amount, String timestamp) 
	{
		this.subscriberId = subscriberId;
		this.amount = amount;
		this.timestamp = timestamp;
	}

	public UsageData() 
	{
	}
}