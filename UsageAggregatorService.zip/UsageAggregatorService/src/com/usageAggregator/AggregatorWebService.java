/** 
 * This class is created to implement the reportUsage and getAggregatedUsage Rest APIs.
 * reportUsage, informing how many bytes were used by a given subscriber at an specific timestamp.
 * getAggregatedUsage, retrieving what was the total usage consumed by a given subscriber per day.
 */

package com.usageAggregator;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

@Path("/AggregatorWebService")
public class AggregatorWebService<T> 
{
	/**
	 * This API is used to inform how bytes were used by a given subscriber at an specific timestamp.
	 * @param usageData containing subscriberId, usage, timestamp.
	 * @return success/not success
	 */
	@POST
	@Path("/reportUsage")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response reportUsage(UsageData usageData) 
	{
		AggregatorService service = new AggregatorService();
		if (usageData == null)
		{
			System.out.println("Input parameters not provided in reportUsage request.");
			return Response.noContent().build();
			
		}
		
		else 
		{
			if(usageData.getSubscriberId() == 0 || usageData.getAmount() == 0 || 
					usageData.getTimestamp()== null)
			{
				System.out.println("Provide valid input parameters in reportUsage request. " +
						"subscriberId, amount should be greater than zero and " +
						"timestamp should not be null.");
				return Response.noContent().build();
			}
		}
		return service.reportUsage(usageData);
	}

	/**
	 * This API is used to retrieve what was the total usage consumed by a given subscriber per day.
	 * @param usageData containing subscriberId
	 * @return List of aggregatedUsages of given subscriber per day.
	 */
	@POST
	@Path("/getAggregatedUsage")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response getAggregatedUsage(UsageData usageData) 
	{
		if (usageData == null)
		{
			System.out.println("Input parameters not provided in getAggregatedUsage request.");
			return Response.noContent().build();
		}
		
		else 
		{
			if(usageData.getSubscriberId() == 0)
			{
				System.out.println("Provide valid input parameters in getAggregatedUsage request. " +
						"subscriberId should be greater than zero.");
				return Response.noContent().build();
			}
		}
		AggregatorService service = new AggregatorService();
		return Response.ok(service.getAggregatedUsage(usageData)).build();
	}
}
